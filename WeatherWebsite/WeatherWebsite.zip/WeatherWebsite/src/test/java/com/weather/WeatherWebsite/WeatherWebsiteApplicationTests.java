package com.weather.WeatherWebsite;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WeatherWebsiteApplicationTests {

	@Test
	void contextLoads() {
	}

}
